{\rtf1\ansi\ansicpg1252\cocoartf949
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\ql\qnatural\pardirnatural

\f0\fs24 \cf0 \
**** WHITE LEOPARD ICON SET README ***\
\
Thanks for downloading the White Leopard Icon Set. Here are some generall information:\
\
- You should only use these icons on Mac OS 10.5 (Leopard)!\
- Make a backup of the changed files before you delete them!\
- It is not allowed to change these icons and go public with it, except you've asked for my permission. You can do this via mail: mail@gedankenpolaroid.de\
\
HOW TO INSTALL:\
\
Changing icons on your Mac is very simple. There are two ways of changing:\
\
(A) ... by using software like 'Candybar'\
(B) ... by changing icons manually\
\
Since changing Icons with software like 'Candybar' is actually fool proof, I'll only explain the manual way.\
\
Simply follow these instructions:\
\
(1) Go to your Harddrive and enter "System"\
(2) Enter "Library"\
(3) Enter "CoreServices"\
(4) Now look for "CoreTypes.bundle". Right-click on it and choose "Show package content"\
(5) Enter "Content", then enter "Resources"\
(6) Look for all the files with a folder icon and copy them to a backup folder somewhere on your Mac. In case you forgot or were too lazy: contact me via mail (mail@gedankenpolaroid.de) and I will send you the standard icons.\
(7) Now place the .icns-files from this folder into the "Resources" folder. You'll probably have to enter your admin password to do so.\
(8) Logout of your Mac or reboot it.\
(9) Done!\
\
Have fun!\
}